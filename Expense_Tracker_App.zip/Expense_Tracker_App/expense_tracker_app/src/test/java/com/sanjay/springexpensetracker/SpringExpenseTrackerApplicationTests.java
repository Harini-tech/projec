package com.sanjay.springexpensetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExpenseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
